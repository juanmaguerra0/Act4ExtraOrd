/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML.java to edit this template
 */
package actividadeval4;


import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Person;
import view.PersonEditDialogController;
import view.PersonOverviewController;

/**
 *
 * @author Juanma
 */
public class ActividadEval4 extends Application {
    
   // Declaramos una variable para el escenario principal de la aplicación.
    private Stage primaryStage;
    
    // Declaramos una variable para el layout principal de la aplicación.
    private BorderPane rootLayout;

    // Declaramos una lista observable de objetos de tipo Person.
    private ObservableList<Person> personData = FXCollections.observableArrayList();

    /**
     * Constructor de la clase Act3Extraord1_1.
     * Aquí se añaden algunas personas a la lista observable.
     */
    public ActividadEval4() {
        personData.add(new Person("Hans", "Muster"));
        personData.add(new Person("Ruth", "Mueller"));
        personData.add(new Person("Heinz", "Kurz"));
        personData.add(new Person("Cornelia", "Meier"));
        personData.add(new Person("Werner", "Meyer"));
        personData.add(new Person("Lydia", "Kunz"));
        personData.add(new Person("Anna", "Best"));
        personData.add(new Person("Stefan", "Meier"));
        personData.add(new Person("Martin", "Mueller"));
    }
  
    /**
     * Método que devuelve la lista observable de personas.
     * @return personData, la lista observable de personas.
     */
    public ObservableList<Person> getPersonData() {
        return personData;
    }
    
    @Override
    public void start(Stage primaryStage) {
        // Guardamos el escenario principal.
        this.primaryStage = primaryStage;
        
        // Establecemos el título del escenario principal.
        this.primaryStage.setTitle("AddressApp");

        // Inicializamos el layout principal.
        initRootLayout();

        // Mostramos la vista general de las personas.
        showPersonOverview();
    }
    
    /**
     * Método que inicializa el layout principal.
     */
    public void initRootLayout() {
        try {
            // Cargamos el layout principal desde un archivo fxml.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(ActividadEval4.class.getResource("/view/RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();
            
            // Mostramos la escena que contiene el layout principal.
            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Método que muestra la vista general de las personas dentro del layout principal.
     */
    public void showPersonOverview() {
        try {
            // Cargamos la vista general de las personas.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(ActividadEval4.class.getResource("/view/PersonOverview.fxml"));
            AnchorPane personOverview = (AnchorPane) loader.load();

            // Establecemos la vista general de las personas en el centro del layout principal.
            rootLayout.setCenter(personOverview);

            // Damos al controlador acceso a la aplicación principal.
            PersonOverviewController controller = loader.getController();
            controller.setMainApp(this);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
 
    /**
 * Abre un diálogo para editar los detalles de la persona especificada. Si el usuario
 * hace clic en OK, los cambios se guardan en el objeto de la persona proporcionado y se devuelve true.
 * 
 * @param person el objeto de la persona que se va a editar
 * @return true si el usuario hizo clic en OK, false en caso contrario.
 */
public boolean showPersonEditDialog(Person person) {
    try {
        // Carga el archivo fxml y crea una nueva etapa para el diálogo emergente.
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(ActividadEval4.class.getResource("/view/PersonEditDialog.fxml"));
        AnchorPane page = (AnchorPane) loader.load();

        // Crea la etapa del diálogo.
        Stage dialogStage = new Stage();
        dialogStage.setTitle("Editar Persona");
        dialogStage.initModality(Modality.WINDOW_MODAL);
        dialogStage.initOwner(primaryStage);
        Scene scene = new Scene(page);
        dialogStage.setScene(scene);

        // Establece la persona en el controlador.
        PersonEditDialogController controller = loader.getController();
        controller.setDialogStage(dialogStage);
        controller.setPerson(person);

        // Muestra el diálogo y espera hasta que el usuario lo cierre
        dialogStage.showAndWait();

        return controller.isOkClicked();
    } catch (IOException e) {
        e.printStackTrace();
        return false;
    }
}

    
    /**
     * Método que devuelve el escenario principal.
     * @return primaryStage, el escenario principal.
     */
    public Stage getPrimaryStage() {
        return primaryStage;
    }

    // Método principal que lanza la aplicación.
    public static void main(String[] args) {
        launch(args);
    }
    
}
